<?php

/**
 * As of version 11.0.0 this file is no longer needed
 *
 * It is only included in the setup to override the file when upgrading from an earlier version
 */
 
 ?>